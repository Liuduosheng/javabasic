import java.util.Scanner;

public class Example02 {

	public static void main(String[] args) {
		// 四则运算(+、-、*、\、%)，使用switch多分支选择结构来实现简易的计算器功能

		Scanner input = new Scanner(System.in);
		System.out.print("请输入第一个操作数：");
		double numberA = input.nextDouble();

		System.out.print("请输入运算符(+、-、×、÷、%):");
		/*
		 * charAt(int index) : char 返回指定索引处的 char 值。
		 * */
		char opr = input.next().charAt(0);

		System.out.print("请输入第二个操作数：");
		double numberB = input.nextDouble();
		double result = 0.0;
		switch (opr) {
			case '+':
				result = numberA + numberB;
				break;
			case '-':
				result = numberA - numberB;
				break;
			case '×':
				result = numberA * numberB;
				break;
			case '÷':
				if(numberB == 0){
					System.out.println("除数不能为零。");
				}
				else{
					result = numberA / numberB;
				}
				break;
			case '%':
				if(numberB == 0){
					System.out.println("除数不能为零。");
				}
				else{
					result = numberA % numberB;
				}
				break;
			default:
				break;
		}
		
		System.out.printf("计算的结果为：%.2f %c %.2f = %.2f\n",
				numberA,opr,numberB,result);

	}

}
