import java.util.Scanner;

public class Example05 {

	public static void main(String[] args) {
		
//		  (1)、刘承勋为自己的手机设定了自动拨号功能
//			按1：拨爸爸的号
//			按2：拨妈妈的号
//			按3：拨爷爷的号
//			按4：拨奶奶的号

		
	
	     /*Scanner input = new Scanner(System.in);
	     System.out.print("请输入快捷号：");
			int week = input.nextInt();
			switch (week) {
			case 1:
				System.out.println("拨爸爸的号");
				break;
			case 2:
				System.out.println("拨妈妈的号");
				break;
			case 3:
				System.out.println("拨爷爷的号");
				break;
			case 4:
				System.out.println("拨奶奶的号");
				break;
			default:
				System.out.println("你输入的不正确");
				break;
			}
		*/
		/*
		 *(2)、根据从命令行参数获取的月份，打印该月份所属的季节。  
    	3,4,5 春季 6,7,8 夏季  9,10,11 秋季 12, 1, 2 冬季  
		 * */
		/*canner input=new Scanner(System.in);
		System.out.println("请输入月份：");
		int month=input.nextInt();
		switch(month){
			case 3:
			case 4:
			case 5:
				System.out.println("春季");
				break;
			case 6:
			case 7:
			case 8:
				System.out.println("夏季");
				break;
			case 9:
			case 10:
			case 11:
				System.out.println("秋季");
				break;
			case 12:
			case 1:
			case 2:
				System.out.println("冬季");
				break;
			default:
				System.out.println("请输入正确的月份");
		}*/
		
		
		/*3)、从键盘读入一个学生成绩，
		 * 存放在变量score中，根据score的值输出其对应的成绩等级。
		 * 当score >= 90时，  输出“成绩等级为优秀。”
		 * 当score >= 80时，  输出“成绩等级为良好。”
		 * 当score >= 70时，  输出“成绩等级为中等。”
		 * 当score >= 60时，  输出“成绩等级为一般。”
		 * 当score < 60 时，   输出“成绩等级为较差。”
		 * */
		
		/*Scanner input = new Scanner(System.in);
		System.out.println("请输入学生的成绩");
		int score = input.nextInt();
		switch(score/10){
			case 10:
			case 9:
				System.out.println("成绩等级为优秀");
				break;
			case 8:
				System.out.println("成绩等级为良好");
				break;
			case 7:
				System.out.println("成绩等级为中等");
				break;
			case 6:
				System.out.println("成绩等级为一般");
				break;
			default:
				System.out.println("成绩等级为较差");
		}
		*/
		
		/*
		 * (4)、使用switch多分支选择结构实现把小写字母转换为大写字母。
		 *     仅转换a,b,c,d,e，输入其它字母，
		 *     提示”仅支持a,b,c,d,e字母转换。“
		 * */
		Scanner input = new Scanner(System.in);
		System.out.println("请输入小写字母：");
		char letter = input.next().charAt(0);
		switch(letter){
			case 'a':
				letter='a'-32;
				break;
			case 'b':
				letter='b'-32;
				break;
			case 'c':
				letter='c'-32;
				break;
			case 'd':
				letter='d'-32;
				break;
			case 'e':
				letter='e'-32;
				break;
				
		
		}
		System.out.print(letter);

	}
}


