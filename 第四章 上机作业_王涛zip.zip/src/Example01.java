
public class Example01 {

	public static void main(String[] args) {
		/*
		 * 韩嫣参加计算机编程大赛
			如果获得第一名，将参加麻省理工大学组织的1个月夏令营
			如果获得第二名，将奖励惠普笔记本电脑一部
			如果获得第三名，将奖励移动硬盘一个
			否则，不给任何奖励

		 * */
		
		int grade = 4;
		//使用多重if条件结构实现
		/*if (grade == 1) {
			System.out.println("第一名，参加麻省理工大学组织的1个月夏令营。");
		} else if(grade == 2) {
			System.out.println("第二名，奖励惠普笔记本电脑一部。");
		} else if(grade == 3){
			System.out.println("第三名，奖励移动硬盘一个");
		}else{
			System.out.println("不给任何奖励。");
		}*/
		
		//使用switch条件结构实现
		switch (grade) {
			case 1:
				System.out.println("第一名，参加麻省理工大学组织的1个月夏令营。");
				break;
			case 2:
				System.out.println("第二名，奖励惠普笔记本电脑一部。");
				break;
			case 3:
				System.out.println("第三名，奖励移动硬盘一个");
				break;
			default:
				System.out.println("不给任何奖励。");
				break;
				
		}

	}

}
